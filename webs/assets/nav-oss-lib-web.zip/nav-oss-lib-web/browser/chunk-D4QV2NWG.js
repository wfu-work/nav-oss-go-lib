var s={production:!0,useHash:!1,api:{baseUrl:"/api"},oss:{apiBaseUrl:"/v1"}};export{s as a};
